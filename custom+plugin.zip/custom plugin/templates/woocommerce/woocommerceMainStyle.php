	<style>
			form.woocommerce-form.woocommerce-form-login.login {
			    border: 3px solid #1c284e;
			}

			form.woocommerce-form.woocommerce-form-register.register {
			    border: 3px solid #1c284e;
			}

			button.woocommerce-button.button.woocommerce-form-login__submit.wp-element-button {
			    border-radius: 30px 30px 30px 30px;
			    padding: 10px 15px 10px 15px;
			    background: #1c284e;
			    color: white;
			}

			button.woocommerce-Button.woocommerce-button.button.wp-element-button.woocommerce-form-register__submit {
			    border-radius: 30px 30px 30px 30px;
			    padding: 10px 15px 10px 15px;
			    background: #1c284e;
			    color: white;
			}
			div#customer_login {margin-top: 5%;}
			nav.woocommerce-MyAccount-navigation {
			    background-color: #ffffff;
			    border-radius: 8px;
			    padding: 5px;
			    border: 1px solid #ccc;
			    margin-bottom: 50px;
			    position: -webkit-sticky;
			    position: sticky;
			    top: 100px;
			    right: 0;
			    z-index: 2;
			    
			}

			li.woocommerce-MyAccount-navigation-link {
			    padding: 13px;
			    display: flex;
			    align-items: center;
			    color: #1c284e !important;
			    margin: 5px 1px;
			    transition: all 0.3s ease-in-out;
			    border-radius: 4px;
			    border: 1px solid #f5f4de;
			}

			li.woocommerce-MyAccount-navigation-link.is-active {
			    background-color: #1c284e;
			}

			li.woocommerce-MyAccount-navigation-link.is-active a {
			    color: white !important;
			}

			li.woocommerce-MyAccount-navigation-link a {
			    font-weight: 500;
			    text-decoration: none;
			    color: #1c284e !important;
			}

			/*li.woocommerce-MyAccount-navigation-link:hover {
			    background-color: #1c284e !important;
			    color: white;
			}*/
			.woocommerce-MyAccount-navigation ul {
				padding: 0 !important;
			}
			.woocommerce-MyAccount-content img.attachment-700x500 {
			    border: 3px solid #1c284e;
			    border-radius: 10px;
			    padding: 5px;
			}
			div#chattytrigger {
			    margin: 40px 0;
			    border: 3px solid #1c284e;
			}
			div#chattytrigger {
			    height: 130px;
			    width: 30%;
			}

			#chattytrigger label.btn.btn-outline {
			    padding: 10px;
			}
			#demo {
			    font-size: 40px;
			    font-weight: 600;
			}
			button[name=save_account_details] {
			    margin-top: 20px !important;
			    color: white !important;
			    background: #1c284e !important;
			}
		</style>