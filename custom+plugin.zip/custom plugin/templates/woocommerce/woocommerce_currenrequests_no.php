			<a href="https://al-rhal.com/%d8%a7%d8%ae%d8%aa%d9%8a%d8%a7%d8%b1-%d8%a7%d9%84%d8%b9%d9%85%d8%a7%d9%84%d8%a9/" class="newOrder">
                <i class="fas fa-file" style="<?php echo ( pll_current_language() == 'en' ) ? 'margin-right: 10px;' : 'margin-left: 10px;'; ?>"></i>
                <div><strong> <?php echo ( pll_current_language() == 'en' ) ? 'Aplly New Request' : 'تقديم طلب جديد'; ?></strong></div>
            </a>

			  <style>
			  	.chatty-cta a {
				    display: inline-block;
				    overflow: hidden;
				    outline: 0;
				    background: var(--ha-ctv-btn-bg-clr);
				    color: var(--ha-ctv-btn-txt-clr);
				    text-transform: uppercase;
				    letter-spacing: 1px;
				    font-weight: 700;
				    text-decoration: none;
				--ha-ctv-btn-txt-clr: #FFFFFF;
				    --ha-ctv-btn-bg-clr: var(
				    --e-global-color-primary );
				    --ha-ctv-btn-border-clr: var(
				    --e-global-color-primary );
				    --ha-ctv-btn-txt-hvr-clr: var(
				    --e-global-color-primary );
				    --ha-ctv-btn-bg-hvr-clr: #FFFFFFFC;
				    --ha-ctv-btn-border-hvr-clr: var(
				    --e-global-color-primary );
				    padding: 8px 15px;
				    border-radius: 23px;
				    margin-top: -30px;
				}
				.chatty-cta a:hover {
					color: white !important;
				}
			  	.customerOption {
				    padding: 5px;
				}

				.customerOption.col-md-4.wow.fadeInUp {
				    width: 33.33333333%;
				    height: 150px;
				    margin: 20px 0;
				    background-color: rgba(0, 161, 154, 0.1254901961);
				}
				.btn-check {
				    position: absolute;
				    clip: rect(0,0,0,0);
				    pointer-events: none;
				}
				.customerOption .btn {
				    padding: 8px 16px;
				    box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1882352941);
				    box-shadow: none;
				    background-color: #ffffff;
				    display: flex;
				    flex-direction: column;
				    height: 100%;
				    position: relative;
				    transition: all 0.3s ease-in-out;
				    border: 2px solid transparent;
				    border-radius: 16px;
				    padding: 25px;
				    cursor: pointer;
				}
				.customerOption .btn img {
				    height: 50px;
				    min-width: 50px;
				    margin: 0 auto 20px;
				    -o-object-fit: contain;
				    object-fit: contain;
				}
				.customerOption .btn span {
				    text-transform: capitalize;
				    font-size: 18px !important;
				    text-align: center;
				    font-weight: 600;
				}
				.counter-time {
					margin-top: 40px;
				}
				
				#progress {
                  position: relative;
                  margin-bottom: 30px;   
                }
                
                #progress-bar {
                  position: absolute;
                  background: lightseagreen;
                  height: 5px;
                  width: 0%;
                  top: 50%;
                  left: 0;
                }
                
                #progress-num {
                  margin: 0;
                  padding: 0;
                  list-style: none;
                  display: flex;
                  justify-content: space-between;
                }
                
                #progress-num::before {
                  content: "";
                  background-color: lightgray;
                  position: absolute;
                  top: 50%;
                  left: 0;
                  height: 5px;
                  width: 100%;
                  z-index: -1;
                }
                
                #progress-num .step {
                  border: 3px solid lightgray;
                  border-radius: 100%;
                  width: 25px;
                  height: 25px;
                  line-height: 25px;
                  text-align: center;
                  background-color: #fff;
                  font-family: sans-serif;
                  font-size: 14px;    
                  position: relative;
                  z-index: 1;
                  padding-top:5%;
                }
                
                #progress-num .step.active {
                  border-color: lightseagreen;
                  background-color: lightseagreen;
                }
                
                
			</style>
